DROP TABLE `PREFIX_pmt_cart_process`;
