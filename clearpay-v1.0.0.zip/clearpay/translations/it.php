<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{clearpay}prestashop>clearpay_e7e35f48cbce0859d908c6b61eafe05b'] = 'Clearpay Payment Gateway';
$_MODULE['<{clearpay}prestashop>clearpay_e2b8db013b62748f28a8f19eaa1ddfbf'] = 'Acquista ora, paga più tardi - Goditi i pagamenti senza interessi';
