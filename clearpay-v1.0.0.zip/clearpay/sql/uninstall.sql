DROP TABLE IF EXISTS `PREFIX_clearpay_cart_process`;
DROP TABLE IF EXISTS `PREFIX_clearpay_order`;
DROP TABLE IF EXISTS `PREFIX_clearpay_config`;
